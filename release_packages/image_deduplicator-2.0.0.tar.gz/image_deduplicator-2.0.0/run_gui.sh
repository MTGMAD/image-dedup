#!/bin/bash
# Linux/macOS shell script to launch Image Deduplicator GUI
echo "Starting Image Deduplicator GUI..."
python3 image_deduplicator.py --gui
